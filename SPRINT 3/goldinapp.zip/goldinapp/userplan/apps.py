from django.apps import AppConfig


class UserplanConfig(AppConfig):
    name = 'userplan'

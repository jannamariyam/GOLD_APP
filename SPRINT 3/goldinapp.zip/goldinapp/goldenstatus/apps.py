from django.apps import AppConfig


class GoldenstatusConfig(AppConfig):
    name = 'goldenstatus'

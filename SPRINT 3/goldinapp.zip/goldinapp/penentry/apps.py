from django.apps import AppConfig


class PenentryConfig(AppConfig):
    name = 'penentry'

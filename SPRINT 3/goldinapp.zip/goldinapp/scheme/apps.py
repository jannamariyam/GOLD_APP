from django.apps import AppConfig


class SchemeConfig(AppConfig):
    name = 'scheme'

from django.conf.urls import url
from scheme import views
urlpatterns=[

]
from django.apps import AppConfig


class CloseaccConfig(AppConfig):
    name = 'closeacc'

from django.apps import AppConfig


class PriceFixedConfig(AppConfig):
    name = 'price_fixed'

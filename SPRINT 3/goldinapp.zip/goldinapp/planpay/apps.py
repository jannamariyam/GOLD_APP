from django.apps import AppConfig


class PlanpayConfig(AppConfig):
    name = 'planpay'
